# Create your views here.
import pdb
from django.views.generic import ListView
from django.db.models import Max, Sum, Avg

from . models import MarketData

class MarketDataList(ListView):
    model = MarketData

# What are the top 5 airports in terms of: Total passengers by origin
class Top5AirportsPaxByOrigin(ListView):
    context_object_name = "airport_list"
    queryset = MarketData.objects \
                        .values('orig_iata_code','orig_city_name') \
                        .annotate(total_pax=Sum('passengers')) \
                        .order_by('-total_pax')[0:5]
    template_name="rankorder_list_origin.html"

# What are the top 5 airports in terms of: Total passengers by destination
class Top5AirportsPaxByDestination(ListView):
    context_object_name = "airport_list"
    queryset = MarketData.objects.values('dest_iata_code','dest_city_name') \
                                 .annotate(total_pax=Sum('passengers')) \
                                 .order_by('-total_pax')[0:5]
    template_name="rankorder_list_destination.html"

    # What are the top 5 airports in terms of:Total freight by origin
    class Top5AirportsFreightByOrigin(ListView):
    context_object_name = "airport_list"
    queryset = MarketData.objects \
                        .values('orig_iata_code','dest_city_name') \
                        .annotate(total_pax=Sum('freight')) \
                        .order_by('-total_pax')[0:5]
    template_name="rankorder_list_origin_freight.html"
    # What are the top 5 airports in terms of:Total freight by destination
    class Top5AirportsfreighByDestination(ListView):
    context_object_name = "airport_list"
    queryset = MarketData.objects.values('dest_iata_code','dest_city_name') \
                                 .annotate(total_pax=Sum('freight')) \
                                 .order_by('-total_pax')[0:5]
    template_name="rankorder_list_destination_freight.html"
    # What are the top 5 airports in terms of:Total mail by origin
    class Top5AirportsMailByOrigin(ListView):
    context_object_name = "airport_list"
    queryset = MarketData.objects \
                        .values('orig_iata_code','orig_city_name') \
                        .annotate(total_pax=Sum('Mail')) \
                        .order_by('-total_pax')[0:5]
    template_name="rankorder_list_origin_mail.html"
    # What are the top 5 airports in terms of:Total mail by destination
      class Top5AirportsMailByDestination(ListView):
    context_object_name = "airport_list"
    queryset = MarketData.objects.values('dest_iata_code','dest_city_name') \
                                 .annotate(total_pax=Sum('Mail')) \
                                 .order_by('-total_pax')[0:5]
    template_name="rankorder_list_destination_Mail.html"                           
    # What are the top 5 airports in terms of:Total distance by origin
      class Top5AirportsDistanceByOrigin(ListView):
    context_object_name = "airport_list"
    queryset = MarketData.objects \
                        .values('orig_iata_code','orig_city_name') \
                        .annotate(total_pax=Sum('Distance')) \
                        .order_by('-total_pax')[0:5]
    template_name="rankorder_list_origin_Distance.html"
    # What are the top 5 airports in terms of:Total distance by destination
        class Top5AirportsDistanceByDestination(ListView):
    context_object_name = "airport_list"
    queryset = MarketData.objects.values('dest_iata_code','dest_city_name') \
                                 .annotate(total_pax=Sum('Distance')) \
                                 .order_by('-total_pax')[0:5]
    template_name="rankorder_list_destination_Distance.html"  

    # Which airport reported the most passengers by month?
     class TopPassengersByMonth(ListView):
    context_object_name = "airport_list"
    template_name="rankorder_list_origin_Passengers_month.html"

    def get_queryset(self):

        month_list = []

        for month in range(1,7):
            queryset = MarketData.objects \
                .values('orig_iata_code',
                        'orig_city_name',
                        'dest_iata_code',
                        'dest_city_name',
                        'month') \
                .filter(month__exact=month) \
                .annotate(total_Passengers=Max('Passengers')) \
                .order_by('-total_Passengers')[0:1]
            
            # off by one error for assignment

            month_list.append(queryset)

        # return list
        return month_list

    # Which airline reported the most freight carried?
 class TopFreightCarried (ListView):
    context_object_name = "airport_list"
    template_name="rankorder_list_Top_Freight.html"

    def get_queryset(self):

             queryset = MarketData.objects \
                .values('orig_iata_code',
                        'orig_city_name',
                        'dest_iata_code',
                        'dest_city_name',
                        'month') \
             .annotate(total_pax=Max('freight')) \
                .order_by('-total_Pax')[0:1]
     
    # Which airline reported the most passengers carried?
class TopPassengersCarried(ListView):
    context_object_name = "airport_list"
    queryset = MarketData.objects \
                        .values('orig_iata_code',
                        'orig_city_name',
                        'dest_iata_code',
                        'dest_city_name',) \
                        .annotate(total_pax=Max(sum('passengers'))) \
                        .order_by('-total_pax')[0:1]
    template_name="rankorder_list_Top_Passenger.html"
 
    # Which airline reported the most mail carried?
    class TopMailCarried(ListView):
    context_object_name = "airport_list"
    queryset = MarketData.objects \
                        .values('orig_iata_code',
                        'orig_city_name',
                        'dest_iata_code',
                        'dest_city_name',) \
                        .annotate(Max_pax=Max(sum('Mail'))) \
                        .order_by('-total_pax')[0:1]
    template_name="rankorder_list_Top_Mail.html"
    # Which airline reported the longest flight distance?
 class TopDistanceFlight(ListView):
    context_object_name = "airport_list" 

    def get_queryset(self):

                    queryset = MarketData.objects \
                .values('orig_iata_code',
                        'orig_city_name',
                        'dest_iata_code',
                        'dest_city_name',
                        'month') \
                .annotate(Max_distance=Max('distance')) \
                .order_by('-total_distance')[0:1]
       template_name="rankorder_list_Top_distance_Flight.html"     
         

    # Rank order passengers carried, by month, for these airlines:AA (American Airlines)
    class RankOrderByMonthAA(ListView):
    context_object_name = "airport_list"
    template_name="rankorder_list_origin_distance_month.html"

    def get_queryset(self):

        month_list = []

        # pdb.set_trace()

        # there are six months worth of data
        # not good ultimately as this is a "hard-coded" fore-knowledge of the data
        for month in range(1,7):
            queryset = MarketData.objects \
                .values('orig_iata_code',
                        'orig_city_name',
                        'dest_iata_code',
                        'dest_city_name',
                        'month') \
                .filter(month__exact=month) \
                .filter(AirLine__Name="American ArirLine") \
                .annotate(rankorder_list=Max('rank')) \
                .order_by('Rank_Order')[0:1]
            
            # off by one error for assignment

            month_list.append(queryset)

        # return list
        return month_list
    # Rank order passengers carried, by month, for these airlines:AS (Alaska Airlines)
     class RankOrderByMonthALA(ListView):
    context_object_name = "airport_list"
    template_name="rankorder_list_origin_distance_month.html"

    def get_queryset(self):

        month_list = []

        # pdb.set_trace()

        # there are six months worth of data
        # not good ultimately as this is a "hard-coded" fore-knowledge of the data
        for month in range(1,7):
            queryset = MarketData.objects \
                .values('orig_iata_code',
                        'orig_city_name',
                        'dest_iata_code',
                        'dest_city_name',
                        'month') \
                .filter(month__exact=month) \
                .filter(AirLine__Name="Alaska ArirLine") \
                .annotate(rankorder_list=Max('rank')) \
                .order_by('Rank_Order')[0:1]
            
            # off by one error for assignment

            month_list.append(queryset)

        # return list
        return month_list
    # Rank order passengers carried, by month, for these airlines:DL (Delta Airlines)
     class RankOrderByMonthDA(ListView):
    context_object_name = "airport_list"
    template_name="rankorder_list_origin_distance_month.html"

    def get_queryset(self):

        month_list = []

        # pdb.set_trace()

        # there are six months worth of data
        # not good ultimately as this is a "hard-coded" fore-knowledge of the data
        for month in range(1,7):
            queryset = MarketData.objects \
                .values('orig_iata_code',
                        'orig_city_name',
                        'dest_iata_code',
                        'dest_city_name',
                        'month') \
                .filter(month__exact=month) \
                .filter(AirLine__Name="Delta ArirLine") \
                .annotate(rankorder_list=Max('rank')) \
                .order_by('Rank_Order')[0:1]
            
            # off by one error for assignment

            month_list.append(queryset)

        # return list
        return month_list
    # Rank order passengers carried, by month, for these airlines:UA (United Airlines)
     class RankOrderByMonthUA(ListView):
    context_object_name = "airport_list"
    template_name="rankorder_list_origin_distance_month.html"

    def get_queryset(self):

        month_list = []

        # pdb.set_trace()

        # there are six months worth of data
        # not good ultimately as this is a "hard-coded" fore-knowledge of the data
        for month in range(1,7):
            queryset = MarketData.objects \
                .values('orig_iata_code',
                        'orig_city_name',
                        'dest_iata_code',
                        'dest_city_name',
                        'month') \
                .filter(month__exact=month) \
                .filter(AirLine__Name="United ArirLine") \
                .annotate(rankorder_list=Max('rank')) \
                .order_by('Rank_Order')[0:1]
            
            # off by one error for assignment

            month_list.append(queryset)

        # return list
        return month_list
    # Rank order passengers carried, by month, for these airlines:WN (Southwest Airlines)
     class RankOrderByMonthWN(ListView):
    context_object_name = "airport_list"
    template_name="rankorder_list_origin_distance_month.html"

    def get_queryset(self):

        month_list = []

        # pdb.set_trace()

        # there are six months worth of data
        # not good ultimately as this is a "hard-coded" fore-knowledge of the data
        for month in range(1,7):
            queryset = MarketData.objects \
                .values('orig_iata_code',
                        'orig_city_name',
                        'dest_iata_code',
                        'dest_city_name',
                        'month') \
                .filter(month__exact=month) \
                .filter(AirLine__Name="Southwest ArirLine") \
                .annotate(rankorder_list=Max('rank')) \
                .order_by('Rank_Order')[0:1]
            
            # off by one error for assignment

            month_list.append(queryset)

        # return list
        return month_list
    # vind the average number of passengers for flights into:LAX (Los Angeles)

        class AVGPassengerintoLAX(ListView):
    context_object_name = "airport_list"
    queryset = MarketData.objects \
                        .values('orig_iata_code',
                        'orig_city_name',
                        'dest_iata_code',
                        'dest_city_name',
                        'month') \
                        .filter(distination="Los Angeles") 
                        .annotate(Avr_pax=Avg('passengers')) \
                        .order_by('-avr_pax')
    template_name="rankorder_list_average_lAX.html"
    # vind the average number of passengers for flights into:SFO (San Francisco)
    
        class AVGPassengerintoSFO(ListView):
    context_object_name = "airport_list"
    queryset = MarketData.objects \
                        .values('orig_iata_code',
                        'orig_city_name',
                        'dest_iata_code',
                        'dest_city_name',
                        'Avr_pax') \
                        .filter(distination="San Francisco") 
                        .annotate(Avr_pax=Avg('passengers')) \
                        .order_by('-avr_pax')
    template_name="rankorder_list_average_SFO.html"
    # vind the average number of passengers for flights into:DFW (Dallas-Fort Worth)
        
        class AVGPassengerintoDFW(ListView):
    context_object_name = "airport_list"
    queryset = MarketData.objects \
                        .values('orig_iata_code',
                        'orig_city_name',
                        'dest_iata_code',
                        'dest_city_name',
                        'Avr_pax') \
                        .filter(distination="Dallas-Fort Worth") 
                        .annotate(Avr_pax=Avg('passengers')) \
                        .order_by('-avr_pax')
    template_name="rankorder_list_average_DFW.html"
    # vind the average number of passengers for flights into:ATL (Atlanta)
      class AVGPassengerintoATL(ListView):
    context_object_name = "airport_list"
    queryset = MarketData.objects \
                        .values('orig_iata_code',
                        'orig_city_name',
                        'dest_iata_code',
                        'dest_city_name',
                        'Avr_pax') \
                        .filter(distination="Atlanta") 
                        .annotate(Avr_pax=Avg('passengers')) \
                        .order_by('-avr_pax')
    template_name="rankorder_list_average_ATL.html"
    # vind the average number of passengers for flights into:ORD (Chicago)
      class AVGPassengerintoORD(ListView):
    context_object_name = "airport_list"
    queryset = MarketData.objects \
                        .values('orig_iata_code',
                        'orig_city_name',
                        'dest_iata_code',
                        'dest_city_name',
                        'Avr_pax') \
                        .filter(Distination="Chicago") 
                        .annotate(Avr_pax=Avg('passengers')) \
                        .order_by('-avr_pax')
    template_name="rankorder_list_average_ORD.html"
    # Find the average volume of freight for flights departing:MIA (Miami)
      class AVGPassengerintoMIA(ListView):
    context_object_name = "airport_list"
    queryset = MarketData.objects \
                        .values('orig_iata_code',
                        'orig_city_name',
                        'dest_iata_code',
                        'dest_city_name',
                        'Avr_pax') \
                        .filter(origin="Miami") 
                        .annotate(Avr_pax=Avg('Freight')) \
                        .order_by('-avr_pax')
    template_name="rankorder_list_average_MIA.html"
    # Find the average volume of freight for flights departing:MEM (Memphis)
     class AVGPassengerintoMIA(ListView):
    context_object_name = "airport_list"
    queryset = MarketData.objects \
                        .values('orig_iata_code',
                        'orig_city_name',
                        'dest_iata_code',
                        'dest_city_name',
                        'Avr_pax') \
                        .filter(origin='Miami') 
                        .annotate(Avr_pax=Avg('Freight')) \
                        .order_by('-avr_pax')
    template_name="rankorder_list_average_MIA.html"
    # Find the average volume of freight for flights departing:JFK (New York JFK)
      class AVGPassengerintoJFK(ListView):
    context_object_name = "airport_list"
    queryset = MarketData.objects \
                        .values('orig_iata_code',
                        'orig_city_name',
                        'dest_iata_code',
                        'dest_city_name',
                        'Avr_pax') \
                        .filter(origin='Miami') 
                        .annotate(Avr_pax=Avg('Freight')) \
                        .order_by('-avr_pax')
    template_name="rankorder_list_average_JFK.html"
    # Find the average volume of freight for flights departing:ANC (Anchorage)
      class AVGPassengerintoANC(ListView):
    context_object_name = "airport_list"
    queryset = MarketData.objects \
                        .values('orig_iata_code',
                        'orig_city_name',
                        'dest_iata_code',
                        'dest_city_name',
                        'Avr_pax') \
                        .filter(origin='Anchorage') 
                        .annotate(Avr_pax=Avg('Freight')) \
                        .order_by('-avr_pax')
    template_name="rankorder_list_average_ANC.html"
    # Find the average volume of freight for flights departing:SDF (Louisville)
     class AVGPassengerintoSDF(ListView):
    context_object_name = "airport_list"
    queryset = MarketData.objects \
                        .values('orig_iata_code',
                        'orig_city_name',
                        'dest_iata_code',
                        'dest_city_name',
                        'Avr_pax') \
                        .filter(origin='Louisville') 
                        .annotate(Avr_pax=Avg('Freight')) \
                        .order_by('-avr_pax')
    template_name="rankorder_list_average_SDF.html"


# Which airport reported the longest distance by month?
class TopDistanceByMonth(ListView):
    context_object_name = "airport_list"
    template_name="rankorder_list_origin_distance_month.html"

    def get_queryset(self):

        month_list = []

        # pdb.set_trace()

        # there are six months worth of data
        # not good ultimately as this is a "hard-coded" fore-knowledge of the data
        for month in range(1,7):
            queryset = MarketData.objects \
                .values('orig_iata_code',
                        'orig_city_name',
                        'dest_iata_code',
                        'dest_city_name',
                        'month') \
                .filter(month__exact=month) \
                .annotate(total_distance=Max('distance')) \
                .order_by('-total_distance')[0:1]
            
            # off by one error for assignment

            month_list.append(queryset)

        # return list
        return month_list

