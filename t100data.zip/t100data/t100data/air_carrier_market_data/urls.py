# urls.py
from django.urls import path
from . views import MarketDataList, \
                    Top5AirportsPaxByOrigin, \
                    Top5AirportsPaxByDestination, \
                    TopDistanceByMonth ,\
                    Top5AirportsPaxByDestination,\
                    Top5AirportsFreightByOrigin, \
                    Top5AirportsfreighByDestination, \
                    Top5AirportsMailByOrigin, \
                    Top5AirportsMailByDestination, \
                    Top5AirportsDistanceByOrigin, \
                    Top5AirportsDistanceByDestination, \
                    TopPassengersByMonth, \
                    TopFreightCarried, \
                    TopPassengersCarried, \
                    TopMailCarried, \
                    TopDistanceFlight, \ 
                    RankOrderByMonthAA, \
                    RankOrderByMonthALA, \
                    RankOrderByMonthDA, \
                    RankOrderByMonthUA, \
                    RankOrderByMonthWN, \
                    AVGPassengerintoLAX, \
                    AVGPassengerintoSFO, \
                    AVGPassengerintoDFW, \
                    AVGPassengerintoATL, \
                    AVGPassengerintoORD, \
                    AVGPassengerintoMIA, \
                    AVGPassengerintoMEM, \
                    AVGPassengerintoJFK, \
                    AVGPassengerintoANC, \
                    AVGPassengerintoSDF, \
                    TopDistanceByMonth, \
  


urlpatterns = [
    path('list/', MarketDataList.as_view(), name="list"),
    path('top5paxorigin/', 
        Top5AirportsPaxByOrigin.as_view(
            extra_context={'title': "Top 5 Airports - Passengers by Origin Airport"}
        ),
        name="top5paxorigin"),
    path('top5paxdestination/',  
        Top5AirportsPaxByDestination.as_view(
            extra_context={'title': "Top 5 Airports - Passengers by Destination Airport"}
        ), 
        name="top5paxdestination"),
    path('topdistance_month/',  
        TopDistanceByMonth.as_view(
            extra_context={'title': "Top Distance by Month"}
        ), 
        name="topdistance_month"),
        
        path('top5freightorigin/', 
        Top5AirportsFreightByOrigin.as_view(
            extra_context={'title': "Top 5 Airports - Freights by Origin Airport"}
        ),
        name="top5freightorigin"),

       path('top5freightDest/', 
       Top5AirportsfreighByDestination.as_view(
            extra_context={'title': "Top 5 Airports - Freights by destination Airport"}
        ),
        name="top5freightDest"),  

        path('top5MailOrigin/', 
       Top5AirportsMailByOrigin.as_view(
            extra_context={'title': "Top 5 Airports - Mail by Origin Airport"}
        ),
        name="top5MailOrigin"), 

         path('top5Maildest/', 
       Top5AirportsMailByDestination.as_view(
            extra_context={'title': "Top 5 Airports - Mail by destination Airport"}
        ),
        name="top5Maildest"), 

             path('top5distanceOrigin/', 
      Top5AirportsDistanceByOrigin.as_view(
            extra_context={'title': "Top 5 Airports - Distance by Origin Airport"}
        ),
        name="top5distanceOrigin"), 

           path('top5distanceDist/', 
      Top5AirportsDistanceByDestination.as_view(
            extra_context={'title': "Top 5 Airports - Distance by destination Airport"}
        ),
        name="top5distanceDist"), 

           path('TopPassengersByMonth/', 
      TopPassengersByMonth.as_view(
            extra_context={'title': "Top Passengers - Top passengers by month"}
        ),
        name="TopPassengersByMonth"), 

            path('TopFreightCarried/', 
      TopFreightCarried.as_view(
            extra_context={'title': "Top Freight - Top Freight by month"}
        ),
        name="TopFreightCarried"), 

               path('TopFreightCarried/', 
      TopFreightCarried.as_view(
            extra_context={'title': "Top Freight - Top Freight Crried"}
        ),
        name="TopFreightCarried"), 

              path('TopPassengersCarried/', 
      TopPassengersCarried.as_view(
            extra_context={'title': "Top Passengers - Top Passengers Crried"}
        ),
        name="TopPassengersCarried"), 

         path('TopMailCarried/', 
      TopMailCarried.as_view(
            extra_context={'title': "Top Mail - Top Mail Crried"}
        ),
        name="TopMailCarried"),  

            path('TopDistanceFlight/', 
      TopDistanceFlight.as_view(
            extra_context={'title': "Top Distance - Top Distance Flight"}
        ),
        name="TopDistanceFlight"),  

     
            path('RankOrderByMonthAA/', 
      RankOrderByMonthAA.as_view(
            extra_context={'title': "Rank Order - Rank Order By Month AA"}
        ),
        name="RankOrderByMonthAA"),    

            path('RankOrderByMonthALA/', 
      RankOrderByMonthALA.as_view(
            extra_context={'title': "Rank Order - Rank Order By Month ALA"}
        ),
        name="RankOrderByMonthALA"), 
        
            path('RankOrderByMonthDA/', 
      RankOrderByMonthDA.as_view(
            extra_context={'title': "Rank Order - Rank Order By Month DA"}
        ),
        name="RankOrderByMonthDA"), 

          path('RankOrderByMonthUA/', 
      RankOrderByMonthUA.as_view(
            extra_context={'title': "Rank Order - Rank Order By Month UA"}
        ),
        name="RankOrderByMonthUA"), 
         
          path('RankOrderByMonthWN/', 
      RankOrderByMonthWN.as_view(
            extra_context={'title': "Rank Order - Rank Order By Month WN"}
        ),
        name="RankOrderByMonthWN"), 

      path('AVGPassengerintoLAX/', 
     AVGPassengerintoLAX.as_view(
            extra_context={'title': "Avg passengers - Avg passengers in to the LAX"}
        ),
        name="AVGPassengerintoLAX"), 

        path('AVGPassengerintoSFO/', 
     AVGPassengerintoSFO.as_view(
            extra_context={'title': "Avg passengers - Avg passengers in to the SFO"}
        ),
        name="AVGPassengerintoSFO"), 

        path('AVGPassengerintoDFW/', 
     AVGPassengerintoDFW.as_view(
            extra_context={'title': "Avg passengers - Avg passengers in to the DFW"}
        ),
        name="AVGPassengerintoDFW"), 

        path('AVGPassengerintoATL/', 
     AVGPassengerintoATL.as_view(
            extra_context={'title': "Avg passengers - Avg passengers in to the ATL"}
        ),
        name="AVGPassengerintoATL"), 

         path('AVGPassengerintoORD/', 
     AVGPassengerintoORD.as_view(
            extra_context={'title': "Avg passengers - Avg passengers in to the ORD"}
        ),
        name="AVGPassengerintoORD"), 

           path('AVGPassengerintoMIA/', 
     AVGPassengerintoMIA.as_view(
            extra_context={'title': "Avg passengers - Avg passengers in to the MIA"}
        ),
        name="AVGPassengerintoMIA"), 

            path('AVGPassengerintoMEM/', 
     AVGPassengerintoMEM.as_view(
            extra_context={'title': "Avg passengers - Avg passengers in to the MEM"}
        ),
        name="AVGPassengerintoMEM"), 

                path('AVGPassengerintoJFK/', 
     AVGPassengerintoJFK.as_view(
            extra_context={'title': "Avg passengers - Avg passengers in to the JFK"}
        ),
        name="AVGPassengerintoJFK"), 

               path('AVGPassengerintoANC/', 
     AVGPassengerintoANC.as_view(
            extra_context={'title': "Avg passengers - Avg passengers in to the ANC"}
        ),
        name="AVGPassengerintoANC"), 

               path('AVGPassengerintoSDF/', 
     AVGPassengerintoSDF.as_view(
            extra_context={'title': "Avg passengers - Avg passengers in to the SDF"}
        ),
        name="AVGPassengerintoSDF"), 

               path('TopDistanceByMonth/', 
     TopDistanceByMonth.as_view(
            extra_context={'title': "Top Distance - Top Distance by Month"}
        ),
        name="TopDistanceByMonth"), 



]